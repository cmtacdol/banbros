<!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>


<!-- Your Chat Plugin code -->
<div class="fb-customerchat" attribution="setup_tool" page_id="1436558313290688"
    logged_in_greeting="Hi! How can we help you? " logged_out_greeting="Hi! How can we help you? ">
</div>
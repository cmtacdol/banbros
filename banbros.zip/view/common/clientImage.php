 <!-- Clients Section -->
 <section class="js-clients u-clients">
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/ablerex.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/acer.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/altec-lansing-vector-logo.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/ANYTEK (1).png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/ASUS.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/BANBROS LOGO TEXT-01 (2).png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/belkin.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/brother.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/EDGECORE.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/Edifier1.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/GD_Logo_Glod_H.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/hikvision.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/IFUTURE LOGO-01.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/Ignite Logo-01.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/KEBOS-01.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/KGuard-Security-Logo-1-5029.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/kodak.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/LIFAair.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/balance.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/LOGO F_D-01.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/Philips_logo_logotype_emblem.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/plantronics.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/SDigital logo+Box-Red_HR.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/Silicon_Power_logo.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/sony.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/tekplay_logo.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/THIEYE.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/Tough-Tested-Logo.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/ubtech.png" alt="Image Description">
        </div>
        <div class="u-clients__item">
          <img class="u-clients__image" src="assets/img-temp/partners/WST.png" alt="Image Description">
        </div>
      </section>
      <!-- End Clients Section -->